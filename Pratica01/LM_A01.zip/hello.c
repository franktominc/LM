int main(){
   puts("Ola");
   return 0;
}
